

const akseslogin = (req,res,next) => {
    const user = req.session.user || "";
    if(user && user.akses){
        next();
    }else if(user && !user.akses){
        next("route")
    }else(
        res.send("login cuy <a href='/login'>Login</a>")
    )
}

export default akseslogin