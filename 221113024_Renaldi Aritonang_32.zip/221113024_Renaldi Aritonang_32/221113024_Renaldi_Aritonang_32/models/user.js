import { sequelize, DataTypes } from "../db/db.js";

const User = sequelize.define('users', {
    email: DataTypes.STRING,
    password: DataTypes.STRING,
    akses: DataTypes.BOOLEAN
})

export default User;