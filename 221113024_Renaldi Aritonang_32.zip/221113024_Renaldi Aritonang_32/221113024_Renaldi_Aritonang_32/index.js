import  express  from "express";
import { sequelize } from "./db/db.js";
import  Absensi  from "./models/absensi.js";
import { getlogin,postlogin,logout } from "./controllers/users.js";
import session from "express-session";
import akseslogin from "./controllers/auth.js";
import User from "./models/user.js";




const app = express();
//untuk mengirim file json
app.use(express.json());
//untuk menjalankan file express
app.use(express.urlencoded({ extended: true }));

app.use(session({
    secret: 'ini adalah kode secret###',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60 * 60 * 1000 }
    // 1 hour
    }))

//jika menggunakan ejs
app.set("view engine", "ejs");


// pengaturan login
app.get("/login",getlogin)
app.post("/login",postlogin)
app.get("/logout",logout)


app.get("/",akseslogin,(req,res) => {
    Absensi.findAll().then(data => {
        res.render("admin/index", { absensi:data,user:req.session.user || "" });
    }).catch((err) => {
        console.log(err);
    })
})
app.get("/",(req,res) => {
    Absensi.findAll().then(data => {
        res.render("index", { absensi:data,user:req.session.user || "" });
    }).catch((err) => {
        console.log(err);
    })
})


app.get("/tambah", (req, res) => {
    res.render("tambah");
});

app.post("/tambah", async (req, res) => {
    const absensi = await Absensi.create(req.body);
    res.redirect("/");
});

app.delete("/hapus/:id", async (req, res) => {
    const absensi = await Absensi.findByPk(req.params.id);
    await absensi.destroy();
    res.redirect("/");
});

app.get("/edit/:id", async (req, res) => {
    const absensi = await Absensi.findByPk(req.params.id);
    res.render("edit", { absensi });
});

app.put("/edit/:id", async (req, res) => {
    const absensi = await Absensi.findByPk(req.params.id);
    await absensi.update(req.body);
    res.status(200).send("Data berhasil diubah");
});


// registrasi
app.get("/registrasi", async (req, res) => {
    res.render("registrasi");
})

app.post("/registrasi", async (req, res) => {
    const {email,password,kpassword} = req.body;
    if(password!== kpassword){
        res.status(400).send("password dan kpassword tidak sama  <a href='/registrasi'>Registrasi</a>");
    }

    User.create({email: email, password: password}).then(() => {
        res.redirect("/login");
    }).catch(err => {console.log(err)})
})

try {
    await sequelize.authenticate();
    console.log("Database berhasil terkoneksi");
} catch (error) {
    console.error("Gagal terkoneksi ke database:", error);
}

app.listen(3000, () => {
    console.log("Server berjalan di 3000");
});
